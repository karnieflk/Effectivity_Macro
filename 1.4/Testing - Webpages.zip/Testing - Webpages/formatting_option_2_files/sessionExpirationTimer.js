      function SessionTimeoutTimer(strLength, mnsToSessionExpiry){
        //Set all of the defaults      
        this.loaded = false;
        this.intHeight = 300;
        this.intDivHeight = 150;
        this.intWidth = 100;
        this.objDiv = null;
        this.objIFr = null;
        this.top = 0;
        this.sessionLength = 1000*60*20;
        if(typeof(strLength)!="undefined")this.sessionLength = strLength;
        var timerWarn = window.setTimeout(loadMessage,this.sessionLength);
        this.maxWait = 1000*60*5;
        this.title = "PDT - Session Expiration Notification";

        this.message = "The PDT session will expire at " +
                        getTime(mnsToSessionExpiry) +
                       ". To restart the session time and to save any changes,"  +
					   " click the 'Save' / 'Next' button in the current page." +
					   " Any unsaved changes will be lost.";
        this.ok = "OK";
        this.expiredMessage = "Your session has expired. All changes made will be lost.";

        var ref = this;
        
        //determine browser height and height of div
        function calcBrowserSize(){
          if(self.innerHeight){
	        ref.intHeight = self.innerHeight;
            ref.intDivHeight = ref.objDiv.scrollHeight;
      	    ref.intWidth = self.innerWidth;
          }
          else if(document.documentElement && document.documentElement.clientHeight){
	        ref.intHeight = document.documentElement.clientHeight;
            ref.intDivHeight = ref.objDiv.clientHeight;
     	    ref.intWidth = document.documentElement.clientWidth;
          }
          else if(document.body){
	        ref.intHeight = document.body.clientHeight;
            ref.intDivHeight = ref.objDiv.clientHeight;
            ref.intWidth = document.body.clientWidth;
          }
          ref.intHeight = parseInt(ref.intHeight);
          ref.intDivHeight = parseInt(ref.intDivHeight);
          ref.intWidth = parseInt(ref.intWidth);
        }


        //Start to display message on scroll
        function loadMessage(){
          if(ref.loaded == false)ref.loaded = createConfirm();        

          //set reference
          ref.objDiv = document.getElementById("divTimer");
          ref.objIFr = document.getElementById("ifrTimer");

          //position block off screen and show it
          ref.objDiv.style.top = "-1000px";
          ref.objIFr.style.top = "-1000px";
          ref.objDiv.style.display = "block";
          ref.objIFr.style.display = "block";
          if(navigator.userAgent.toLowerCase().indexOf("opera") != -1)ref.objIFr.style.visibility = "hidden";
          
          //Set all of the elements text
		  document.getElementById("divButton").style.display = "block";
		  document.getElementById("divContent").innerHTML = ref.message;
		  document.getElementById("divTitle").innerHTML = ref.title;
		  document.getElementById("btnOk").value = ref.ok;
		  
		  //position block to top edge of screen
          calcBrowserSize();
          
          ref.objDiv.style.top = -ref.intDivHeight + "px";
          ref.objIFr.style.top = -ref.intDivHeight + "px";

          ref.objDiv.style.left = Math.floor(ref.intWidth/4) + "px";
          ref.objIFr.style.left = Math.floor(ref.intWidth/4) + "px";
          
          ref.objDiv.style.width = Math.floor(ref.intWidth/2) + "px";
          ref.objIFr.style.width = Math.floor(ref.intWidth/2) + "px";

		  intStop = Math.floor(ref.intHeight/3);
          //prepare block to be scrolled in
          ref.top = -ref.intDivHeight;
          timerScroll = window.setInterval(scrollIn,1);
          timerWait = window.setTimeout(extendedWait,ref.maxWait);
        }

        //Determine how much user scrolled page down 
        function GetScroll(){    
          var scrollY = document.documentElement.scrollTop;
          if(!scrollY)scrollY = document.body.scrollTop;            
          if(!scrollY)scrollY = window.pageYOffset;               
          if(!scrollY)scrollY = 0;
          return scrollY;
        }
        
        //some local(private) variables
        var timerScroll = null;
        var timerReject = null;
        var intStep = 2;
        var intStop = null
//        var intStop = Math.floor(ref.intHeight/1);
    	var timerUpdate = null;
		var intDotCount = 0;
		var timerWait = null;

        //Function moves confirmation window into view
        function scrollIn(){
          if(parseInt(intStep) + parseInt(ref.top) <= parseInt(intStop) ){
            ref.top += intStep;
            var intT = ref.top + GetScroll();;
			ref.objDiv.style.top =  intT + "px";
			ref.objIFr.style.top =  intT + "px";
		 }else{
             var cancel = window.clearInterval(timerScroll);
             ref.objDiv.style.top = GetScroll() + intStop + "px";
             ref.objIFr.style.top = ref.objDiv.style.top;
          }
        }
      

        //Hide information if the ignore button was clicked
		this.clickOk = function(){
          ref.objDiv.style.display = "none";
          ref.objIFr.style.display = "none";
		}

	
		//change message from normal to extended info 
		function extendedWait(){
		  document.getElementById("divContent").innerHTML = ref.expiredMessage;
		  ref.objDiv.style.display = "block";
          ref.objIFr.style.display = "block";
		}
	
       
        function createConfirm(){
          var ifr = document.createElement("iframe");
      
          var div1 = document.createElement("div");
          var div2 = document.createElement("div");
          var div3 = document.createElement("div");
          var div4 = document.createElement("div");
     
          var btn1 = document.createElement("input");
      
          ifr.id = "ifrTimer";
          // The following line of code has been added to avoid 
          // the error message 'This page shows secure and nonsecure items',
          // when the page is deployed in a secure server
          ifr.src = "..\tool\index.jsp";
          
          div1.id = "divTimer";
          div2.id = "divTitle";
          div3.id = "divContent";
          div4.id = "divButton"; 


          btn1.type="button";
          btn1.id = "btnOk";
          btn1.className = "ignore";
          btn1.onclick = function(){sessionTimer.clickOk();return false;}
          btn1.value = "text";
                         
          div1.appendChild(div2);   
          div1.appendChild(div3);
          div4.appendChild(btn1);
          div1.appendChild(div4); 
		  		  
          document.forms[0].appendChild(ifr);
          document.forms[0].appendChild(div1);
          
          return  true;
        }
        
        //Hide div and iframe  
        function hideDiv(){
          ref.objDiv.style.display = "none";
          ref.objIFr.style.display = "none";
        }
     
      }

		function getTime(mnsToSsnExp){
			var now = new Date();
			time = now.getTime();
			now.setTime(time + (1000*60*mnsToSsnExp));
	
			var hours = now.getHours();
			var minutes = now.getMinutes();
			var seconds = now.getSeconds();
			var timeValue = "" + ((hours <10) ? "0" : "") + hours
			timeValue += ((minutes < 10) ? ":0" : ":") + minutes
			timeValue += " hours"
						
			return timeValue;
		}
//=============================================
//Update information here for customization here!
//============================================== 
      //var sessionTimer = new SessionTimeoutTimer();           //default time 20 minutes
      var sessionTimer = new SessionTimeoutTimer(1000*60*50, 60);   // 50 mins
      sessionTimer.maxWait = 1000 * 60 * 10;           				// 10 mins
      